#ifndef PRINTMAP_H
#define PRINTMAP_H

void printMap(char ***map, int mapWidth, int mapHeight,int isCheatModeOn);

#endif
