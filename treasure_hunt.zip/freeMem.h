#ifndef FREEMEM_H
#define FREEMEM_H

void freeMem(char ***map, int mapNumCol, char **treasure, int maxTreasure);
#endif
