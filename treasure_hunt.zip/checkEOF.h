#ifndef CHECKEOF_H
#define CHECKEOF_H



int checkEOFint(int *address);
int checkEOFstr(char *address);

#endif
